# Image→Video Pro (Next.js 14 + ffmpeg.wasm) — Netlify Ready

Готовая студия для конвертации картинок в видео **в браузере**. NSFW запрещён.

## Возможности
- Drag & Drop изображения, предпросмотр
- Редактирование длительности и порядка слайдов
- Параметры: 720p/1080p, FPS
- Музыка (опционально), экспорт MP4 локально

## Деплой на Netlify
1. Загрузите файлы в новый репозиторий GitHub.
2. На Netlify: Add new site → Import from Git.
3. Build command: `npm run build`, Publish: `.next`.
4. Плагин: `@netlify/plugin-nextjs` (см. netlify.toml).
5. Deploy.

## Локальный запуск
```bash
npm install
npm run dev
```
