import Link from "next/link";
import { Wand2, Images, Music2, Film } from "lucide-react";

export default function Page() {
  return (
    <section className="container py-12">
      <div className="text-center max-w-3xl mx-auto">
        <span className="badge">NSFW запрещён</span>
        <h1 className="text-4xl md:text-5xl font-extrabold mt-4">
          Делай видео из картинок прямо в браузере
        </h1>
        <p className="text-gray-600 mt-3">
          Загрузи изображения, добавь музыку и собери видео MP4. Никаких серверов — всё считается локально.
        </p>
        <div className="mt-6 flex items-center justify-center gap-3">
          <Link href="/studio" className="btn"><Wand2 className="h-5 w-5" />Открыть студию</Link>
          <a href="#features" className="btn-secondary">Возможности</a>
        </div>
      </div>

      <div id="features" className="grid md:grid-cols-3 gap-6 mt-12">
        {[
          {icon: Images, title: "Drag & Drop", text: "Перетащи файлы — сразу предпросмотр и тайминг."},
          {icon: Music2, title: "Музыка", text: "Добавь MP3/OGG, мы подрежем по длительности."},
          {icon: Film, title: "Экспорт MP4", text: "Рендер прямо в браузере через ffmpeg.wasm."},
        ].map((f,i)=> (
          <div key={i} className="card p-6">
            <f.icon className="h-6 w-6" />
            <h3 className="font-semibold mt-3">{f.title}</h3>
            <p className="text-sm text-gray-600 mt-1">{f.text}</p>
          </div>
        ))}
      </div>

      <div className="mt-12 text-center">
        <p className="text-gray-600">Готов? Переходи в студию и собирай свой ролик.</p>
        <Link href="/studio" className="btn mt-3">Перейти в студию</Link>
      </div>
    </section>
  );
}
