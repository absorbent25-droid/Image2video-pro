'use client';
import React, { useEffect, useMemo, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { createFFmpeg, fetchFile } from '@ffmpeg/ffmpeg';
import { ArrowDown, ArrowUp, Trash2, Download } from 'lucide-react';

type Slide = { id: string; file: File; url: string; durationSec: number };

const ffmpeg = createFFmpeg({ log: true });
function uid(){ return Math.random().toString(36).slice(2); }

export default function Studio() {
  const [ready, setReady] = useState(false);
  const [slides, setSlides] = useState<Slide[]>([]);
  const [audio, setAudio] = useState<File | null>(null);
  const [fps, setFps] = useState(30);
  const [res, setRes] = useState<'720p'|'1080p'>('720p');
  const [rendering, setRendering] = useState(false);
  const [outputUrl, setOutputUrl] = useState<string | null>(null);

  useEffect(()=>{ (async()=>{ if(!ready){ await ffmpeg.load(); setReady(true);} })(); },[ready]);

  const onDrop = (files: File[]) => {
    const images = files.filter(f=> f.type.startsWith('image/'));
    const next: Slide[] = images.map(f => ({ id: uid(), file: f, url: URL.createObjectURL(f), durationSec: 2 }));
    setSlides(prev => [...prev, ...next]);
  };

  const {getRootProps, getInputProps, isDragActive} = useDropzone({ onDrop, accept: { 'image/*': [] } });

  const totalDuration = useMemo(()=> slides.reduce((a,s)=>a + s.durationSec, 0), [slides]);

  function move(i:number, dir:-1|1){
    const j = i + dir;
    if(j<0 || j>=slides.length) return;
    setSlides(prev => {
      const copy = [...prev];
      [copy[i], copy[j]] = [copy[j], copy[i]];
      return copy;
    });
  }
  function remove(i:number){ setSlides(prev => prev.filter((_,idx)=> idx!==i)); }

  async function render(){
    if (!slides.length) return;
    setRendering(true); setOutputUrl(null);
    try{
      for (let i = 0; i < slides.length; i++) {
        const b = await fetchFile(slides[i].file);
        await ffmpeg.FS('writeFile', `img_${String(i).padStart(3,'0')}.png`, b);
      }
      const list = slides.map((s,i)=> `file 'img_${String(i).padStart(3,'0')}.png'\n` + `duration ${Math.max(0.1, s.durationSec).toFixed(2)}`).join('\n');
      await ffmpeg.FS('writeFile','input.txt', new TextEncoder().encode(list + "\n"));
      const scale = res==='1080p' ? '1920:1080' : '1280:720';
      await ffmpeg.run(
        '-f','concat','-safe','0','-i','input.txt',
        '-framerate', String(fps),
        '-vf', `scale=${scale}:force_original_aspect_ratio=decrease,pad=${scale}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`,
        '-pix_fmt','yuv420p',
        'temp.mp4'
      );
      if (audio) {
        await ffmpeg.FS('writeFile','music', await fetchFile(audio));
        await ffmpeg.run(
          '-stream_loop','-1','-i','music',
          '-i','temp.mp4','-shortest',
          '-map','1:v:0','-map','0:a:0',
          '-c:v','libx264','-pix_fmt','yuv420p',
          'output.mp4'
        );
      } else {
        await ffmpeg.run('-i','temp.mp4','-c:v','copy','output.mp4');
      }
      const data = ffmpeg.FS('readFile','output.mp4');
      const url = URL.createObjectURL(new Blob([data.buffer], { type: 'video/mp4' }));
      setOutputUrl(url);
    } finally{ setRendering(false); }
  }

  return (
    <section className="container py-8">
      <h1 className="text-3xl font-bold">Студия</h1>
      <p className="text-gray-600 mt-1">Соберите ролик из изображений. Все вычисления происходят у вас в браузере.</p>

      <div className="grid md:grid-cols-3 gap-6 mt-6">
        <div className="md:col-span-2">
          <div {...getRootProps()} className={"card p-6 border-dashed " + (isDragActive? "bg-blue-50 border-blue-400" : "")}>
            <input {...getInputProps()} />
            <p className="text-gray-600">Перетащите сюда изображения или нажмите для выбора.</p>
          </div>

          <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {slides.map((s, i) => (
              <div key={s.id} className="card overflow-hidden">
                <img src={s.url} className="h-40 w-full object-cover" />
                <div className="p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Слайд {i+1}</span>
                    <div className="flex items-center gap-1">
                      <button className="btn-secondary px-2 py-1" onClick={()=>move(i,-1)} title="Вверх"><ArrowUp className="h-4 w-4" /></button>
                      <button className="btn-secondary px-2 py-1" onClick={()=>move(i,1)} title="Вниз"><ArrowDown className="h-4 w-4" /></button>
                      <button className="btn-secondary px-2 py-1" onClick={()=>remove(i)} title="Удалить"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </div>
                  <label className="label">Длительность (сек.)</label>
                  <input type="number" min={0.2} step={0.1} value={s.durationSec}
                    onChange={(e)=>{
                      const v = Number(e.target.value || 0.2);
                      setSlides(prev => prev.map((p, idx)=> idx===i? {...p, durationSec: v}: p));
                    }} className="input" />
                </div>
              </div>
            ))}
          </div>
        </div>

        <aside className="card p-6 h-fit sticky top-20">
          <h3 className="font-semibold">Параметры</h3>
          <div className="mt-3 space-y-3">
            <div>
              <label className="label">FPS</label>
              <input type="number" min={1} max={60} value={fps} onChange={e=>setFps(Number(e.target.value||30))} className="input" />
            </div>
            <div>
              <label className="label">Разрешение</label>
              <select value={res} onChange={e=>setRes(e.target.value as any)} className="input">
                <option value="720p">1280×720</option>
                <option value="1080p">1920×1080</option>
              </select>
            </div>
            <div>
              <label className="label">Музыка (опционально)</label>
              <input type="file" accept="audio/*" onChange={e=>setAudio(e.target.files?.[0]||null)} className="block" />
            </div>
            <div className="text-sm text-gray-600">Кадров: ~{Math.round(totalDuration*fps)} • Длительность: {totalDuration.toFixed(1)}с</div>
            <button className="btn w-full" onClick={render} disabled={!slides.length || rendering || !ready}>
              {rendering ? "Рендер..." : "Собрать видео"}
            </button>
            {outputUrl && (
              <div className="mt-3 space-y-2">
                <video src={outputUrl} controls className="w-full rounded-xl" />
                <a href={outputUrl} download className="btn-secondary w-full inline-flex justify-center">Скачать MP4</a>
              </div>
            )}
            {!ready && <div className="text-xs text-gray-500">Загрузка ffmpeg.wasm…</div>}
          </div>
        </aside>
      </div>
    </section>
  );
}
