import "./globals.css";
import Link from "next/link";
import type { ReactNode } from "react";

export const metadata = {
  title: "Image → Video Studio",
  description: "Конвертация картинок в видео прямо в браузере. Без NSFW.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="min-h-screen site-gradient">
        <header className="border-b bg-white/60 backdrop-blur sticky top-0 z-10">
          <div className="container flex h-14 items-center justify-between">
            <Link href="/" className="font-bold">Image→Video</Link>
            <nav className="flex items-center gap-4">
              <Link className="navlink" href="/studio">Студия</Link>
              <Link className="navlink" href="/faq">FAQ</Link>
              <Link className="navlink" href="/pricing">Цены</Link>
              <Link className="navlink" href="/privacy">Privacy</Link>
              <Link className="navlink" href="/terms">Terms</Link>
              <a className="btn-secondary" href="https://github.com/" target="_blank" rel="noreferrer">GitHub</a>
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="mt-16 border-t">
          <div className="container py-8 text-sm text-gray-500 flex flex-wrap gap-2 justify-between">
            <span>© {new Date().getFullYear()} Image→Video. NSFW запрещён.</span>
            <span>Сделано на Next.js + ffmpeg.wasm</span>
          </div>
        </footer>
      </body>
    </html>
  );
}
